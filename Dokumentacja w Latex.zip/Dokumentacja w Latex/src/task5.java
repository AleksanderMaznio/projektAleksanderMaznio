  // Usuwanie osobówki na podstawie numeru z listy
    private static void usunOsobowke() throws IOException {
        if (DodajPojazd.listaOsobowek.isEmpty()) {
            System.out.println("\nBrak osobowek w bazie!");
            return;
        }

        // Wyświetlenie listy osobówek
        System.out.println("\nLista osobowek:");
        for (int i = 0; i < DodajPojazd.listaOsobowek.size(); i++) {
            Osobowka o = DodajPojazd.listaOsobowek.get(i);
            System.out.printf("%d. ID: %d | %s %s (rocznik: %d, miejsca: %d)\n",
                    i + 1, o.getId(), o.getMarka(), o.getModel(),
                    o.getRokProdukcji(), o.getLiczbaMiejsc());
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("\nPodaj numer osobowki do usunięcia: ");
        int index = scanner.nextInt() - 1;

        // Usunięcie pojazdu z listy
        if (index >= 0 && index < DodajPojazd.listaOsobowek.size()) {
            int usunieteId = DodajPojazd.listaOsobowek.get(index).getId();
            DodajPojazd.listaOsobowek.remove(index);
            OdczytZapis.zapiszPojazdy();
            System.out.printf("\nOsobowka o ID %d została usunięta!\n", usunieteId);
        } else {
            System.out.println("\nNieprawidłowy numer!"); } }