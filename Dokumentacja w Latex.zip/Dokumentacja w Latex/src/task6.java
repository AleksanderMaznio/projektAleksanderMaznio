private static void edytujOsobowke() throws IOException {
        if (DodajPojazd.listaOsobowek.isEmpty()) {
            System.out.println("\nBrak osobowek w bazie!");
            return;
        }

        System.out.println("\nLista osobowek:");
        for (int i = 0; i < DodajPojazd.listaOsobowek.size(); i++) {
            Osobowka o = DodajPojazd.listaOsobowek.get(i);
            System.out.printf("%d. ID: %d | %s %s (rocznik: %d, miejsca: %d)\n",
                    i + 1, o.getId(), o.getMarka(), o.getModel(),
                    o.getRokProdukcji(), o.getLiczbaMiejsc());
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("\nPodaj numer osobowki do edycji: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine(); // Wyczyść bufor

        if (index < 0 || index >= DodajPojazd.listaOsobowek.size()) {
            System.out.println("Nieprawidłowy numer!");
            return;
        }

        Osobowka o = DodajPojazd.listaOsobowek.get(index);
        System.out.println("\nEdycja pojazdu ID: " + o.getId());

        // Edycja marki
        System.out.print("Nowa marka [" + o.getMarka() + "]: ");
        String nowaMarka = scanner.nextLine();
        if (!nowaMarka.isEmpty()) {
            o.setMarka(nowaMarka);
        }

        // Edycja modelu
        System.out.print("Nowy model [" + o.getModel() + "]: ");
        String nowyModel = scanner.nextLine();
        if (!nowyModel.isEmpty()) {
            o.setModel(nowyModel);
        }

        // Edycja rocznika
        System.out.print("Nowy rocznik [" + o.getRokProdukcji() + "]: ");
        String rocznikInput = scanner.nextLine();
        if (!rocznikInput.isEmpty()) {
            try {
                int nowyRocznik = Integer.parseInt(rocznikInput);
                if (nowyRocznik >= 1900 && nowyRocznik <= Calendar.getInstance().get(Calendar.YEAR)) {
                    o.setRokProdukcji(nowyRocznik);
                } else {
                    System.out.println("Nieprawidłowy rocznik! Pozostawiono poprzednią wartość.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Nieprawidłowy format roku! Pozostawiono poprzednią wartość.");
            }
        }

        // Edycja liczby miejsc
        System.out.print("Nowa liczba miejsc [" + o.getLiczbaMiejsc() + "]: ");
        String miejscaInput = scanner.nextLine();
        if (!miejscaInput.isEmpty()) {
            try {
                int noweMiejsca = Integer.parseInt(miejscaInput);
                if (noweMiejsca > 0) {
                    o.setLiczbaMiejsc(noweMiejsca);
                } else {
                    System.out.println("Liczba miejsc musi być dodatnia! Pozostawiono poprzednią wartość.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Nieprawidłowy format! Pozostawiono poprzednią wartość.");
            }
        }

        OdczytZapis.zapiszPojazdy();
        System.out.println("\nPojazd został zaktualizowany!");
    }