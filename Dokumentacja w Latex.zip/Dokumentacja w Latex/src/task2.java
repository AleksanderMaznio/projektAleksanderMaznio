 public static void zapiszPojazdy() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(NAZWA_PLIKU))) {
            // Zapisz wszystkie osobówki do pliku
            for (Osobowka o : DodajPojazd.listaOsobowek) {
                writer.println(String.format("%s;%d;%s;%s;%d;%d",
                        TYP_OSOBOWKA,
                        o.getId(),
                        o.getMarka(),
                        o.getModel(),
                        o.getRokProdukcji(),
                        o.getLiczbaMiejsc()));
            }

            // Zapisz wszystkie dostawczaki do pliku
            for (Dostawczak d : DodajPojazd.lisaDostawczakow) {
                writer.println(String.format("%s;%d;%s;%s;%d;%.2f",
                        TYP_DOSTAWCZAK,
                        d.getId(),
                        d.getMarka(),
                        d.getModel(),
                        d.getRokProdukcji(),
                        d.getLadownosc()));
            }

            System.out.println("Zapisano pojazdy do pliku (" +
                    DodajPojazd.listaOsobowek.size() + " osobowek, " +
                    DodajPojazd.lisaDostawczakow.size() + " dostawczaków)");

        } catch (IOException e) {
            System.err.println("Błąd zapisu do pliku: " + e.getMessage());
        }
    }