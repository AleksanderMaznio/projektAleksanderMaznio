  // Dodaje nową osobówkę z walidacją danych
    private static void dodajOsobowke() throws IOException, PojazdException {
        Scanner scanner = new Scanner(System.in);

        System.out.print("\nPodaj markę: ");
        String marka = scanner.nextLine();

        System.out.print("Podaj model: ");
        String model = scanner.nextLine();

        System.out.print("Podaj rocznik: ");
        int rocznik = scanner.nextInt();
        if (rocznik < 1900 || rocznik > Calendar.getInstance().get(Calendar.YEAR)) {
            throw new ZlyRocznikException(); // walidacja rocznika
        }

        System.out.print("Podaj liczbę miejsc: ");
        int miejsca = scanner.nextInt();
        if (miejsca <= 0) {
            throw new ZlaLiczbaMiejscException(); // walidacja liczby miejsc
        }

        // Tworzenie i dodanie nowej osobówki
        Osobowka nowa = new Osobowka(marka, model, rocznik, miejsca);
        nowa.setId(OdczytZapis.getNoweId()); // unikalne ID
        listaOsobowek.add(nowa);

        OdczytZapis.zapiszPojazdy();
        System.out.printf("\nDodano osobówkę! ID: %d\n", nowa.getId());
    }