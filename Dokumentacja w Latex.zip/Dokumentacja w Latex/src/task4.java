  /**
     * Metoda wczytuje pojazdy z pliku przy uruchomieniu programu.
     * Wczytane pojazdy są dodawane do odpowiednich list w klasie DodajPojazd.
     */
    public static void wczytajPrzyUruchomieniu() {
        // Wyczyść listy przed wczytaniem nowych danych
        DodajPojazd.listaOsobowek.clear();
        DodajPojazd.lisaDostawczakow.clear();
        najwyzszeId = 0;

        try {
            File plik = new File(NAZWA_PLIKU);

            // Jeśli plik nie istnieje, wypisz info i zakończ wczytywanie
            if (!plik.exists()) {
                System.out.println("Brak pliku danych - zostanie utworzony przy pierwszym zapisie");
                return;
            }

            // Odczyt linii z pliku
            try (Scanner scanner = new Scanner(plik)) {
                while (scanner.hasNextLine()) {
                    String linia = scanner.nextLine().trim();

                    if (linia.isEmpty()) continue;

                    // Zamień przecinki na kropki, by poprawnie sparsować floaty
                    linia = linia.replace(",", ".");

                    String[] dane = linia.split(";");

                    // Sprawdź czy linia ma wystarczającą ilość pól
                    if (dane.length < 6) {
                        System.err.println("Nieprawidłowy format linii: " + linia);
                        continue;
                    }

                    try {
                        // Parsuj ID i aktualizuj najwyższeId jeśli trzeba
                        int id = Integer.parseInt(dane[1]);
                        if (id > najwyzszeId) {
                            najwyzszeId = id;
                        }

                        // Rozpoznaj typ pojazdu i utwórz odpowiedni obiekt
                        switch (dane[0]) {
                            case TYP_OSOBOWKA:
                                Osobowka o = new Osobowka(
                                        dane[2],                             // marka
                                        dane[3],                             // model
                                        Integer.parseInt(dane[4]),          // rok produkcji
                                        Integer.parseInt(dane[5])           // liczba miejsc
                                );
                                o.setId(id);
                                DodajPojazd.listaOsobowek.add(o);
                                break;

                            case TYP_DOSTAWCZAK:
                                Dostawczak d = new Dostawczak(
                                        dane[2],                             // marka
                                        dane[3],                             // model
                                        Integer.parseInt(dane[4]),          // rok produkcji
                                        Float.parseFloat(dane[5])           // pojemność (ładowność)
                                );
                                d.setId(id);
                                DodajPojazd.lisaDostawczakow.add(d);
                                break;

                            default:
                                System.err.println("Nieznany typ pojazdu: " + dane[0]);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Błąd parsowania liczby w linii: " + linia);
                    }
                }
            }

            System.out.println("Wczytano " + DodajPojazd.listaOsobowek.size() +
                    " osobowek i " + DodajPojazd.lisaDostawczakow.size() +
                    " dostawczaków");

        } catch (IOException e) {
            System.err.println("Błąd podczas wczytywania pliku: " + e.getMessage());
        }
    }